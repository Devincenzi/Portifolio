@extends('layout.app')

@section('content')

<campo-cobra></campo-cobra>

@endsection