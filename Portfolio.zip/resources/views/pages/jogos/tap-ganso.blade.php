@extends('layout.app')

@section('content')

<div class='flex flex-col justify-around items-center'>
        <span class='font-bold text-sky-500 py-6 text-xl'>CONSTRUINDO...</span>
        <img src='/images/WEB-DEVELOPMENT.gif'/>
    </div>

@endsection