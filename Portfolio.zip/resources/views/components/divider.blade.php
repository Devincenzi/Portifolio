<div class='h-2 w-full flex justify-center'>
    <div class='bg-slate-700 divider h-full w-3/4'></div>
</div>