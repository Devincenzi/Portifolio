<div class='text-gray-300 font-semibold p-4 max-w-fit cursor-pointer transition ease-in-out duration-300 hover:bg-indigo-300 hover:text-slate-700'>
    {{ $slot }}
</div>