<span class="cursor-pointer inline-flex items-center px-1 pt-1 border-b-4 border-transparent text-sm font-medium leading-5 text-gray-300 hover:text-gray-200 hover:border-indigo-300 focus:outline-none focus:text-gray-200 focus:border-indigo-400 transition duration-150 ease-in-out">
    {{ $slot }}
</span>