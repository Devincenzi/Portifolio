<template>
    <span class="px-4 py-2 font-semibold text-slate-100 hover:bg-indigo-400 rounded-lg">
        <slot/>
    </span>
</template>